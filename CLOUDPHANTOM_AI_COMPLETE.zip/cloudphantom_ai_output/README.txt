CLOUDPHANTOM AI v3.0
Cloud Failure Prediction & Recovery Intelligence

Includes synthetic telemetry, Isolation Forest anomaly detection, dependency analysis, blast-radius estimates, recovery strategy ranking, interactive charts, evaluation metrics, tests, CSV and JSON exports.

Simulation-only prototype. No AWS account or production infrastructure is accessed. Validate on independent telemetry before production use.
